//Name : Rahul Singh Ub email : rsingh33@buffalo.edu

public class CDLList<T> {

	Element head = null;

	// Create a CDLList with one value
	public CDLList(T v) {

		Element node = new Element();
		node.value = v;
		node.next = node;
		node.previous = node;
		head = node;
		System.out.println(v);
	}

	public class Element {
		RWLock lock = new RWLock();

		T value;
		Element next;
		Element previous;

		// return the element�s value
		public T value() {
			return this.value;
		}
	}

	// Return the head of the list. Never null
	public Element head() {
		return this.head;
	}

	// Return a cursor at element from in the list
	public Cursor reader(Element from) {

		Cursor newCursor = new Cursor(from);
		return newCursor;
	}

	// A cursor on an invalid element throws an exception.
	public class Cursor {

		Element cursorPosition;

		public Cursor(Element from) {
			this.cursorPosition = from;
		}

		// Return the current position at which the cursor points.
		public Element current() {

			return this.cursorPosition;

		}

		// Move to the previous element.
		public void previous() {
			this.cursorPosition = this.cursorPosition.previous;
		}

		// Move to the next element
		public void next() {
			this.cursorPosition = this.cursorPosition.next;
		}

		// Returns the current position at which writer points
		public Writer writer() {
			Writer writerPosition = new Writer(this.current());
			return writerPosition;
		}
	}

	// A cursor on an invalid element throws an exception.
	public class Writer {

		Element writerPosition;

		public Writer(Element from) {
			writerPosition = from;

		}

		// Add before the current element.
		public boolean insertBefore(T val) {

			Element node2 = new Element();
			node2.value = val;
			writerPosition.previous.next = node2;
			node2.previous = writerPosition.previous;
			node2.next = writerPosition;
			writerPosition.previous = node2;

			return true;
		}

		// Add after the current element.
		public boolean insertAfter(T val) {
			Element node2 = new Element();
			node2.value = val;
			writerPosition.next.previous = node2;
			node2.next = writerPosition.next;
			node2.previous = writerPosition;
			writerPosition.next = node2;
			return true;

		}

	}

	public void print(CDLList<T> f) {

		CDLList<T>.Cursor c;
		c = f.reader(f.head());

		while (true) {
			c.previous();
			System.out.println(c.current().value);
			if (f.head() == c.current()) {
				break;
			}

		}
	}

}
