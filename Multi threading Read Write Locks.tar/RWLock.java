// Name : Rahul Singh Ub email : rsingh33@buffalo.edu

public class RWLock {

	private final java.util.concurrent.atomic.AtomicInteger lock;
	Object myLock = new Object();

	public RWLock() {
		lock = new java.util.concurrent.atomic.AtomicInteger(1);

	}

	// get the lock state and increment it.....

	public void lockRead() throws InterruptedException {
		{
			//lock.incrementAndGet();
			int n = lock.get();
			//
			while (!lock.compareAndSet(n, ++n)){
				if ((lock.get() <= 0)) {

					synchronized (this) {
						try {
							
							this.wait();
						} catch (InterruptedException e) {

							e.printStackTrace();
						}
					}

				}	

			}

		}
	}

	// Two cases to be handled for < - 1 and < 1

	public void unlockRead() throws InterruptedException {
		if (lock.get() < -1) {
			lock.set(lock.get() + 1);
		}

		if (lock.get() > 1) {
			lock.set(lock.get() - 1);
		}
		//lock.set(1);

		synchronized (this) {
			this.notifyAll();

		}

	}

	// lock state(1,-1)

	public void lockWrite() throws InterruptedException {
//		lock.incrementAndGet();
		int n;
		while (!(lock.compareAndSet(-1, 0) || lock.compareAndSet(1, 0)));
		

		if (lock.get() > 0 || lock.get() < -1) {
			if ((n = lock.get()) > 1) {
				lock.compareAndSet(n, n * (-1));
			}
			synchronized (this) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			//lock.incrementAndGet();

		}

		//lock.set(lock.get() - 1);

	}

	public void unlockWrite() throws InterruptedException {

//		lock.set(1);

		synchronized (this) {
			lock.set(lock.get() + 1);
			this.notifyAll();
		}

	}

}
